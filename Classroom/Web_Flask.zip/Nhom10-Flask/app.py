from flask import Flask, render_template, request, redirect, url_for
import json
import os

# Try to import matplotlib; if unavailable or broken (Pillow issues), we
# continue but disable chart generation and show a friendly message.
MATPLOTLIB_AVAILABLE = False
try:
    import matplotlib
    matplotlib.use('Agg')  # non-GUI backend
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except Exception as exc:
    plt = None
    MATPLOTLIB_AVAILABLE = False
    _MATPLOTLIB_IMPORT_ERROR = str(exc)

app = Flask(__name__)

DATA_FILE = 'data.json'
STATS_IMG = 'static/stats.png'

# In-memory storage (global list)
entries = []  # list of dicts: {id, name, message}
next_id = 1


def load_data():
    global entries, next_id
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                entries.clear()
                entries.extend(data)
                if entries:
                    next_id = max(e.get('id', 0) for e in entries) + 1
                else:
                    next_id = 1
        except Exception:
            entries.clear()
            next_id = 1
    else:
        entries.clear()
        next_id = 1


def save_data():
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


# Load data on import to ensure entries are initialized. Avoid @app.before_first_request
# which is not available in some older/stripped Flask environments.
load_data()


@app.route('/')
def index():
    return render_template('index.html', entries=entries)


@app.route('/add', methods=['GET', 'POST'])
def add_entry():
    global entries, next_id
    if request.method == 'POST':
        name = (request.form.get('name') or '').strip()
        message = (request.form.get('message') or '').strip()
        if not name or not message:
            error = 'Cả tên và lời nhắn đều bắt buộc.'
            return render_template('add.html', error=error, name=name, message=message)
        entry = {
            'id': next_id,
            'name': name,
            'message': message,
        }
        next_id += 1
        entries.append(entry)
        save_data()
        return redirect(url_for('index'))
    return render_template('add.html', error=None, name='', message='')


@app.route('/delete/<int:id>', methods=['POST', 'GET'])
def delete_entry(id: int):
    global entries
    entries = [e for e in entries if e.get('id') != id]
    save_data()
    return redirect(url_for('index'))


@app.route('/stats')
def stats():
    # Tổng số lời nhắn
    total = len(entries)
    # Đếm số lượng lời nhắn theo name
    from collections import Counter
    name_counts = Counter(e['name'] for e in entries)
    # 5 người gửi nhiều nhất
    top5 = name_counts.most_common(5)

    # Vẽ biểu đồ cột - thử matplotlib trước, rồi fallback SVG
    chart_url = None
    chart_error = None
    
    # Thử matplotlib nếu khả dụng
    if name_counts and MATPLOTLIB_AVAILABLE:
        try:
            names = [n for n, _ in name_counts.most_common()]
            counts = [name_counts[n] for n in names]
            plt.figure(figsize=(8, 4))
            plt.bar(names, counts, color='#4a90e2')
            plt.xlabel('Người gửi')
            plt.ylabel('Số lời nhắn')
            plt.title('Thống kê số lượng lời nhắn theo người gửi')
            plt.tight_layout()
            # Ensure static directory exists
            os.makedirs(os.path.dirname(STATS_IMG), exist_ok=True)
            plt.savefig(STATS_IMG)
            plt.close()
            chart_url = url_for('static', filename='stats.png')
        except Exception as exc:
            chart_error = str(exc)
    
    # Nếu matplotlib không thành công, thử SVG fallback
    if name_counts and chart_url is None:
        try:
            names = [n for n, _ in name_counts.most_common()]
            counts = [name_counts[n] for n in names]
            max_count = max(counts) if counts else 1
            width = 800
            bar_height = 30
            gap = 10
            height = (bar_height + gap) * len(counts) + 40
            max_bar_width = width - 220
            svg_parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">']
            svg_parts.append('<style>.label{font:14px sans-serif;} .count{font:12px sans-serif;fill:#666}</style>')
            y = 20
            for name, cnt in zip(names, counts):
                bar_w = 0 if max_count == 0 else int(cnt / max_count * max_bar_width)
                svg_parts.append(f'<rect x="200" y="{y}" width="{bar_w}" height="{bar_height}" fill="#4a90e2" />')
                svg_parts.append(f'<text x="10" y="{y + bar_height/1.6}" class="label">{name}</text>')
                svg_parts.append(f'<text x="{200 + bar_w + 8}" y="{y + bar_height/1.6}" class="count">{cnt}</text>')
                y += bar_height + gap
            svg_parts.append('</svg>')
            svg_content = '\n'.join(svg_parts)
            svg_path = os.path.join('static', 'stats.svg')
            os.makedirs(os.path.dirname(svg_path), exist_ok=True)
            with open(svg_path, 'w', encoding='utf-8') as f:
                f.write(svg_content)
            chart_url = url_for('static', filename='stats.svg')
            # SVG thành công, xóa lỗi trước đó
            chart_error = None
        except Exception as exc:
            # Nếu cả SVG cũng thất bại
            if chart_error is None:  # chưa có lỗi từ matplotlib
                chart_error = 'Không thể tạo biểu đồ SVG: ' + str(exc)
            # giữ nguyên chart_error từ matplotlib nếu đã có

    return render_template('stats.html', total=total, top5=top5, chart_url=chart_url, chart_error=chart_error)



if __name__ == '__main__':
    load_data()
    app.run(host='0.0.0.0', port=5000, debug=True)
