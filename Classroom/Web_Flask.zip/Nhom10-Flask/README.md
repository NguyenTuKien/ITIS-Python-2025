# Flask Guestbook (simple)

Ứng dụng Flask rất nhỏ cho phép khách để lại lời nhắn.

Các route:
- `/` (GET): Hiển thị tất cả lời nhắn
- `/add` (GET, POST): Thêm lời nhắn
- `/delete/<id>` (POST hoặc GET): Xóa lời nhắn

Chạy ứng dụng:

```bash
python3 app.py
```

Cài dependencies:

```bash
python3 -m pip install -r requirements.txt
```
